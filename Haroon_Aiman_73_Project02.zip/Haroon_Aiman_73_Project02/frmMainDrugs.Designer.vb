﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmMainDrugs
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.lstDrugs = New System.Windows.Forms.ListBox()
        Me.lblMainTitle = New System.Windows.Forms.Label()
        Me.hdrDrugNDC = New System.Windows.Forms.Label()
        Me.hdrDrugName = New System.Windows.Forms.Label()
        Me.hdrDosage = New System.Windows.Forms.Label()
        Me.hdrDesc = New System.Windows.Forms.Label()
        Me.hdrUnitPrice = New System.Windows.Forms.Label()
        Me.hdrCostPrice = New System.Windows.Forms.Label()
        Me.hdrDrugType = New System.Windows.Forms.Label()
        Me.hdrSupplier = New System.Windows.Forms.Label()
        Me.hdrInStock = New System.Windows.Forms.Label()
        Me.hdrCount = New System.Windows.Forms.Label()
        Me.hdrCategory = New System.Windows.Forms.Label()
        Me.hdrDateRecieved = New System.Windows.Forms.Label()
        Me.btnAddDrug = New System.Windows.Forms.Button()
        Me.btnChange = New System.Windows.Forms.Button()
        Me.btnAbout = New System.Windows.Forms.Button()
        Me.lblDrugNDC = New System.Windows.Forms.Label()
        Me.lblDrugName = New System.Windows.Forms.Label()
        Me.lblDesc = New System.Windows.Forms.Label()
        Me.lblDateRecieved = New System.Windows.Forms.Label()
        Me.lblPackagePrice = New System.Windows.Forms.Label()
        Me.lblDrugType = New System.Windows.Forms.Label()
        Me.lblSupplier = New System.Windows.Forms.Label()
        Me.lblDosage = New System.Windows.Forms.Label()
        Me.lblInStock = New System.Windows.Forms.Label()
        Me.lblCount = New System.Windows.Forms.Label()
        Me.lblUnitPrice = New System.Windows.Forms.Label()
        Me.lblCategory = New System.Windows.Forms.Label()
        Me.pnlResults = New System.Windows.Forms.Panel()
        Me.lblUnitQuantity = New System.Windows.Forms.Label()
        Me.hdrUnitQuantity = New System.Windows.Forms.Label()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.pnlResults.SuspendLayout()
        Me.SuspendLayout()
        '
        'lstDrugs
        '
        Me.lstDrugs.BackColor = System.Drawing.Color.AliceBlue
        Me.lstDrugs.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lstDrugs.Font = New System.Drawing.Font("Consolas", 8.0!)
        Me.lstDrugs.FormattingEnabled = True
        Me.lstDrugs.ItemHeight = 15
        Me.lstDrugs.Location = New System.Drawing.Point(31, 88)
        Me.lstDrugs.Name = "lstDrugs"
        Me.lstDrugs.Size = New System.Drawing.Size(392, 347)
        Me.lstDrugs.TabIndex = 0
        '
        'lblMainTitle
        '
        Me.lblMainTitle.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblMainTitle.Font = New System.Drawing.Font("Modern No. 20", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMainTitle.ForeColor = System.Drawing.Color.DarkSlateGray
        Me.lblMainTitle.Location = New System.Drawing.Point(333, 9)
        Me.lblMainTitle.Name = "lblMainTitle"
        Me.lblMainTitle.Size = New System.Drawing.Size(555, 63)
        Me.lblMainTitle.TabIndex = 1
        Me.lblMainTitle.Text = "Pharmacy Drugs Inventory"
        Me.lblMainTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'hdrDrugNDC
        '
        Me.hdrDrugNDC.AutoSize = True
        Me.hdrDrugNDC.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.hdrDrugNDC.Location = New System.Drawing.Point(25, 33)
        Me.hdrDrugNDC.Name = "hdrDrugNDC"
        Me.hdrDrugNDC.Size = New System.Drawing.Size(37, 17)
        Me.hdrDrugNDC.TabIndex = 2
        Me.hdrDrugNDC.Text = "NDC"
        '
        'hdrDrugName
        '
        Me.hdrDrugName.AutoSize = True
        Me.hdrDrugName.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.hdrDrugName.Location = New System.Drawing.Point(25, 79)
        Me.hdrDrugName.Name = "hdrDrugName"
        Me.hdrDrugName.Size = New System.Drawing.Size(80, 17)
        Me.hdrDrugName.TabIndex = 3
        Me.hdrDrugName.Text = "Drug Name"
        '
        'hdrDosage
        '
        Me.hdrDosage.AutoSize = True
        Me.hdrDosage.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.hdrDosage.Location = New System.Drawing.Point(25, 123)
        Me.hdrDosage.Name = "hdrDosage"
        Me.hdrDosage.Size = New System.Drawing.Size(57, 17)
        Me.hdrDosage.TabIndex = 4
        Me.hdrDosage.Text = "Dosage"
        '
        'hdrDesc
        '
        Me.hdrDesc.AutoSize = True
        Me.hdrDesc.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.hdrDesc.Location = New System.Drawing.Point(25, 168)
        Me.hdrDesc.Name = "hdrDesc"
        Me.hdrDesc.Size = New System.Drawing.Size(79, 17)
        Me.hdrDesc.TabIndex = 5
        Me.hdrDesc.Text = "Description"
        '
        'hdrUnitPrice
        '
        Me.hdrUnitPrice.AutoSize = True
        Me.hdrUnitPrice.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.hdrUnitPrice.Location = New System.Drawing.Point(25, 246)
        Me.hdrUnitPrice.Name = "hdrUnitPrice"
        Me.hdrUnitPrice.Size = New System.Drawing.Size(69, 17)
        Me.hdrUnitPrice.TabIndex = 6
        Me.hdrUnitPrice.Text = "Unit Price"
        '
        'hdrCostPrice
        '
        Me.hdrCostPrice.AutoSize = True
        Me.hdrCostPrice.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.hdrCostPrice.Location = New System.Drawing.Point(16, 284)
        Me.hdrCostPrice.Name = "hdrCostPrice"
        Me.hdrCostPrice.Size = New System.Drawing.Size(99, 17)
        Me.hdrCostPrice.TabIndex = 7
        Me.hdrCostPrice.Text = "Package Price"
        '
        'hdrDrugType
        '
        Me.hdrDrugType.AutoSize = True
        Me.hdrDrugType.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.hdrDrugType.Location = New System.Drawing.Point(417, 66)
        Me.hdrDrugType.Name = "hdrDrugType"
        Me.hdrDrugType.Size = New System.Drawing.Size(75, 17)
        Me.hdrDrugType.TabIndex = 8
        Me.hdrDrugType.Text = "Drug Type"
        '
        'hdrSupplier
        '
        Me.hdrSupplier.AutoSize = True
        Me.hdrSupplier.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.hdrSupplier.Location = New System.Drawing.Point(417, 26)
        Me.hdrSupplier.Name = "hdrSupplier"
        Me.hdrSupplier.Size = New System.Drawing.Size(60, 17)
        Me.hdrSupplier.TabIndex = 9
        Me.hdrSupplier.Text = "Supplier"
        '
        'hdrInStock
        '
        Me.hdrInStock.AutoSize = True
        Me.hdrInStock.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.hdrInStock.Location = New System.Drawing.Point(417, 210)
        Me.hdrInStock.Name = "hdrInStock"
        Me.hdrInStock.Size = New System.Drawing.Size(58, 17)
        Me.hdrInStock.TabIndex = 10
        Me.hdrInStock.Text = "In Stock"
        '
        'hdrCount
        '
        Me.hdrCount.AutoSize = True
        Me.hdrCount.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.hdrCount.Location = New System.Drawing.Point(417, 246)
        Me.hdrCount.Name = "hdrCount"
        Me.hdrCount.Size = New System.Drawing.Size(45, 17)
        Me.hdrCount.TabIndex = 11
        Me.hdrCount.Text = "Count"
        '
        'hdrCategory
        '
        Me.hdrCategory.AutoSize = True
        Me.hdrCategory.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.hdrCategory.Location = New System.Drawing.Point(417, 116)
        Me.hdrCategory.Name = "hdrCategory"
        Me.hdrCategory.Size = New System.Drawing.Size(65, 17)
        Me.hdrCategory.TabIndex = 12
        Me.hdrCategory.Text = "Category"
        '
        'hdrDateRecieved
        '
        Me.hdrDateRecieved.AutoSize = True
        Me.hdrDateRecieved.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.hdrDateRecieved.Location = New System.Drawing.Point(391, 284)
        Me.hdrDateRecieved.Name = "hdrDateRecieved"
        Me.hdrDateRecieved.Size = New System.Drawing.Size(101, 17)
        Me.hdrDateRecieved.TabIndex = 13
        Me.hdrDateRecieved.Text = "Date Recieved"
        '
        'btnAddDrug
        '
        Me.btnAddDrug.BackColor = System.Drawing.Color.Azure
        Me.btnAddDrug.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnAddDrug.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAddDrug.ForeColor = System.Drawing.Color.DarkSlateGray
        Me.btnAddDrug.Location = New System.Drawing.Point(79, 455)
        Me.btnAddDrug.Name = "btnAddDrug"
        Me.btnAddDrug.Size = New System.Drawing.Size(159, 33)
        Me.btnAddDrug.TabIndex = 14
        Me.btnAddDrug.Text = "&Add New Drug"
        Me.btnAddDrug.UseVisualStyleBackColor = False
        '
        'btnChange
        '
        Me.btnChange.BackColor = System.Drawing.Color.Azure
        Me.btnChange.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnChange.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnChange.ForeColor = System.Drawing.Color.DarkSlateGray
        Me.btnChange.Location = New System.Drawing.Point(587, 455)
        Me.btnChange.Name = "btnChange"
        Me.btnChange.Size = New System.Drawing.Size(149, 33)
        Me.btnChange.TabIndex = 15
        Me.btnChange.Text = "C&hange Drug"
        Me.btnChange.UseVisualStyleBackColor = False
        '
        'btnAbout
        '
        Me.btnAbout.BackColor = System.Drawing.Color.Azure
        Me.btnAbout.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnAbout.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAbout.ForeColor = System.Drawing.Color.DarkSlateGray
        Me.btnAbout.Location = New System.Drawing.Point(1102, 21)
        Me.btnAbout.Name = "btnAbout"
        Me.btnAbout.Size = New System.Drawing.Size(68, 33)
        Me.btnAbout.TabIndex = 17
        Me.btnAbout.Text = "About"
        Me.btnAbout.UseVisualStyleBackColor = False
        '
        'lblDrugNDC
        '
        Me.lblDrugNDC.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblDrugNDC.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblDrugNDC.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDrugNDC.Location = New System.Drawing.Point(133, 30)
        Me.lblDrugNDC.Name = "lblDrugNDC"
        Me.lblDrugNDC.Size = New System.Drawing.Size(216, 25)
        Me.lblDrugNDC.TabIndex = 18
        Me.lblDrugNDC.Text = "NDC"
        '
        'lblDrugName
        '
        Me.lblDrugName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblDrugName.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblDrugName.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDrugName.Location = New System.Drawing.Point(133, 70)
        Me.lblDrugName.Name = "lblDrugName"
        Me.lblDrugName.Size = New System.Drawing.Size(216, 26)
        Me.lblDrugName.TabIndex = 19
        Me.lblDrugName.Text = "Drug Name"
        '
        'lblDesc
        '
        Me.lblDesc.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblDesc.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblDesc.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDesc.Location = New System.Drawing.Point(133, 158)
        Me.lblDesc.Name = "lblDesc"
        Me.lblDesc.Size = New System.Drawing.Size(596, 34)
        Me.lblDesc.TabIndex = 20
        Me.lblDesc.Text = "Description of the Drug goes here"
        Me.lblDesc.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblDateRecieved
        '
        Me.lblDateRecieved.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblDateRecieved.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblDateRecieved.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDateRecieved.Location = New System.Drawing.Point(514, 284)
        Me.lblDateRecieved.Name = "lblDateRecieved"
        Me.lblDateRecieved.Size = New System.Drawing.Size(216, 24)
        Me.lblDateRecieved.TabIndex = 21
        Me.lblDateRecieved.Text = "09/28/2021"
        '
        'lblPackagePrice
        '
        Me.lblPackagePrice.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblPackagePrice.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblPackagePrice.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPackagePrice.Location = New System.Drawing.Point(133, 284)
        Me.lblPackagePrice.Name = "lblPackagePrice"
        Me.lblPackagePrice.Size = New System.Drawing.Size(215, 25)
        Me.lblPackagePrice.TabIndex = 22
        Me.lblPackagePrice.Text = "Package Price"
        '
        'lblDrugType
        '
        Me.lblDrugType.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblDrugType.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblDrugType.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDrugType.Location = New System.Drawing.Point(514, 66)
        Me.lblDrugType.Name = "lblDrugType"
        Me.lblDrugType.Size = New System.Drawing.Size(215, 26)
        Me.lblDrugType.TabIndex = 23
        Me.lblDrugType.Text = "Drug Type"
        '
        'lblSupplier
        '
        Me.lblSupplier.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblSupplier.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblSupplier.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSupplier.Location = New System.Drawing.Point(514, 26)
        Me.lblSupplier.Name = "lblSupplier"
        Me.lblSupplier.Size = New System.Drawing.Size(215, 25)
        Me.lblSupplier.TabIndex = 24
        Me.lblSupplier.Text = "Supplier"
        '
        'lblDosage
        '
        Me.lblDosage.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblDosage.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblDosage.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDosage.Location = New System.Drawing.Point(133, 113)
        Me.lblDosage.Name = "lblDosage"
        Me.lblDosage.Size = New System.Drawing.Size(215, 27)
        Me.lblDosage.TabIndex = 25
        Me.lblDosage.Text = "Dosage"
        '
        'lblInStock
        '
        Me.lblInStock.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblInStock.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblInStock.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblInStock.Location = New System.Drawing.Point(514, 207)
        Me.lblInStock.Name = "lblInStock"
        Me.lblInStock.Size = New System.Drawing.Size(215, 27)
        Me.lblInStock.TabIndex = 26
        Me.lblInStock.Text = "Yes/No"
        '
        'lblCount
        '
        Me.lblCount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblCount.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblCount.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCount.Location = New System.Drawing.Point(514, 243)
        Me.lblCount.Name = "lblCount"
        Me.lblCount.Size = New System.Drawing.Size(215, 25)
        Me.lblCount.TabIndex = 27
        Me.lblCount.Text = "Count"
        '
        'lblUnitPrice
        '
        Me.lblUnitPrice.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblUnitPrice.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblUnitPrice.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblUnitPrice.Location = New System.Drawing.Point(133, 243)
        Me.lblUnitPrice.Name = "lblUnitPrice"
        Me.lblUnitPrice.Size = New System.Drawing.Size(216, 25)
        Me.lblUnitPrice.TabIndex = 28
        Me.lblUnitPrice.Text = "Unit Price"
        '
        'lblCategory
        '
        Me.lblCategory.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblCategory.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblCategory.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCategory.Location = New System.Drawing.Point(514, 113)
        Me.lblCategory.Name = "lblCategory"
        Me.lblCategory.Size = New System.Drawing.Size(215, 27)
        Me.lblCategory.TabIndex = 29
        Me.lblCategory.Text = "Category"
        '
        'pnlResults
        '
        Me.pnlResults.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlResults.Controls.Add(Me.lblUnitQuantity)
        Me.pnlResults.Controls.Add(Me.hdrUnitQuantity)
        Me.pnlResults.Controls.Add(Me.lblDosage)
        Me.pnlResults.Controls.Add(Me.lblCategory)
        Me.pnlResults.Controls.Add(Me.hdrDrugNDC)
        Me.pnlResults.Controls.Add(Me.lblUnitPrice)
        Me.pnlResults.Controls.Add(Me.hdrDrugName)
        Me.pnlResults.Controls.Add(Me.lblCount)
        Me.pnlResults.Controls.Add(Me.hdrDosage)
        Me.pnlResults.Controls.Add(Me.lblInStock)
        Me.pnlResults.Controls.Add(Me.hdrDesc)
        Me.pnlResults.Controls.Add(Me.hdrUnitPrice)
        Me.pnlResults.Controls.Add(Me.lblSupplier)
        Me.pnlResults.Controls.Add(Me.hdrCostPrice)
        Me.pnlResults.Controls.Add(Me.lblDrugType)
        Me.pnlResults.Controls.Add(Me.hdrDrugType)
        Me.pnlResults.Controls.Add(Me.lblPackagePrice)
        Me.pnlResults.Controls.Add(Me.hdrSupplier)
        Me.pnlResults.Controls.Add(Me.lblDateRecieved)
        Me.pnlResults.Controls.Add(Me.hdrInStock)
        Me.pnlResults.Controls.Add(Me.lblDesc)
        Me.pnlResults.Controls.Add(Me.hdrCount)
        Me.pnlResults.Controls.Add(Me.lblDrugName)
        Me.pnlResults.Controls.Add(Me.hdrCategory)
        Me.pnlResults.Controls.Add(Me.lblDrugNDC)
        Me.pnlResults.Controls.Add(Me.hdrDateRecieved)
        Me.pnlResults.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.pnlResults.Location = New System.Drawing.Point(446, 88)
        Me.pnlResults.Name = "pnlResults"
        Me.pnlResults.Size = New System.Drawing.Size(756, 347)
        Me.pnlResults.TabIndex = 30
        '
        'lblUnitQuantity
        '
        Me.lblUnitQuantity.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblUnitQuantity.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblUnitQuantity.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblUnitQuantity.Location = New System.Drawing.Point(134, 209)
        Me.lblUnitQuantity.Name = "lblUnitQuantity"
        Me.lblUnitQuantity.Size = New System.Drawing.Size(215, 25)
        Me.lblUnitQuantity.TabIndex = 31
        Me.lblUnitQuantity.Text = "Quantity/Unit"
        '
        'hdrUnitQuantity
        '
        Me.hdrUnitQuantity.AutoSize = True
        Me.hdrUnitQuantity.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.hdrUnitQuantity.Location = New System.Drawing.Point(25, 210)
        Me.hdrUnitQuantity.Name = "hdrUnitQuantity"
        Me.hdrUnitQuantity.Size = New System.Drawing.Size(90, 17)
        Me.hdrUnitQuantity.TabIndex = 30
        Me.hdrUnitQuantity.Text = "Quantity/Unit"
        '
        'btnExit
        '
        Me.btnExit.BackColor = System.Drawing.Color.Azure
        Me.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.ForeColor = System.Drawing.Color.DarkSlateGray
        Me.btnExit.Location = New System.Drawing.Point(1048, 455)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(108, 33)
        Me.btnExit.TabIndex = 31
        Me.btnExit.Text = "E&xit"
        Me.btnExit.UseVisualStyleBackColor = False
        '
        'frmMainDrugs
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.AliceBlue
        Me.BackgroundImage = Global.Haroon_Aiman_73_Project02.My.Resources.Resources.unnamed
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(1221, 517)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.pnlResults)
        Me.Controls.Add(Me.btnAbout)
        Me.Controls.Add(Me.btnChange)
        Me.Controls.Add(Me.btnAddDrug)
        Me.Controls.Add(Me.lblMainTitle)
        Me.Controls.Add(Me.lstDrugs)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.Name = "frmMainDrugs"
        Me.Text = "Drugs Inventory (Aiman Haroon #73)"
        Me.pnlResults.ResumeLayout(False)
        Me.pnlResults.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents lstDrugs As ListBox
    Friend WithEvents lblMainTitle As Label
    Friend WithEvents hdrDrugNDC As Label
    Friend WithEvents hdrDrugName As Label
    Friend WithEvents hdrDosage As Label
    Friend WithEvents hdrDesc As Label
    Friend WithEvents hdrUnitPrice As Label
    Friend WithEvents hdrCostPrice As Label
    Friend WithEvents hdrDrugType As Label
    Friend WithEvents hdrSupplier As Label
    Friend WithEvents hdrInStock As Label
    Friend WithEvents hdrCount As Label
    Friend WithEvents hdrCategory As Label
    Friend WithEvents hdrDateRecieved As Label
    Friend WithEvents btnAddDrug As Button
    Friend WithEvents btnChange As Button
    Friend WithEvents btnAbout As Button
    Friend WithEvents lblDrugNDC As Label
    Friend WithEvents lblDrugName As Label
    Friend WithEvents lblDesc As Label
    Friend WithEvents lblDateRecieved As Label
    Friend WithEvents lblPackagePrice As Label
    Friend WithEvents lblDrugType As Label
    Friend WithEvents lblSupplier As Label
    Friend WithEvents lblDosage As Label
    Friend WithEvents lblInStock As Label
    Friend WithEvents lblCount As Label
    Friend WithEvents lblUnitPrice As Label
    Friend WithEvents lblCategory As Label
    Friend WithEvents pnlResults As Panel
    Friend WithEvents btnExit As Button
    Friend WithEvents lblUnitQuantity As Label
    Friend WithEvents hdrUnitQuantity As Label
End Class
