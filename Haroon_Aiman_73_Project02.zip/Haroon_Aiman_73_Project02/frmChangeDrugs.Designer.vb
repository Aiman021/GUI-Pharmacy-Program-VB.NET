﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmChangeDrugs
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.hdrDrugNDC = New System.Windows.Forms.Label()
        Me.hdrDrugName = New System.Windows.Forms.Label()
        Me.hdrDosage = New System.Windows.Forms.Label()
        Me.hdrDesc = New System.Windows.Forms.Label()
        Me.hdrUnitPrice = New System.Windows.Forms.Label()
        Me.hdrPackagePrice = New System.Windows.Forms.Label()
        Me.hdrDateRecieved = New System.Windows.Forms.Label()
        Me.hdrDrugType = New System.Windows.Forms.Label()
        Me.hdrSupplier = New System.Windows.Forms.Label()
        Me.hdrCategory = New System.Windows.Forms.Label()
        Me.ddlSupplier = New System.Windows.Forms.ComboBox()
        Me.lstCategory = New System.Windows.Forms.ListBox()
        Me.radOTC = New System.Windows.Forms.RadioButton()
        Me.radControlled = New System.Windows.Forms.RadioButton()
        Me.radAntibiotic = New System.Windows.Forms.RadioButton()
        Me.radAntidepressants = New System.Windows.Forms.RadioButton()
        Me.hdrInStock = New System.Windows.Forms.Label()
        Me.hdrCount = New System.Windows.Forms.Label()
        Me.txtDrugName = New System.Windows.Forms.TextBox()
        Me.txtDesc = New System.Windows.Forms.TextBox()
        Me.txtUnitPrice = New System.Windows.Forms.TextBox()
        Me.txtPackagePrice = New System.Windows.Forms.TextBox()
        Me.txtCount = New System.Windows.Forms.TextBox()
        Me.dtpDateRecieved = New System.Windows.Forms.DateTimePicker()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.chkInStock = New System.Windows.Forms.CheckBox()
        Me.txtDosage = New System.Windows.Forms.TextBox()
        Me.mtbNDC = New System.Windows.Forms.MaskedTextBox()
        Me.lblErrorNDC = New System.Windows.Forms.Label()
        Me.lblErrorDrugName = New System.Windows.Forms.Label()
        Me.lblErrorDosage = New System.Windows.Forms.Label()
        Me.lblErrorDesc = New System.Windows.Forms.Label()
        Me.lblErrorUnitP = New System.Windows.Forms.Label()
        Me.lblErrorPkgP = New System.Windows.Forms.Label()
        Me.lblErrorInStock = New System.Windows.Forms.Label()
        Me.lblErrorCount = New System.Windows.Forms.Label()
        Me.lblErrorDate = New System.Windows.Forms.Label()
        Me.lblErrorSupplier = New System.Windows.Forms.Label()
        Me.lblErrorCategory = New System.Windows.Forms.Label()
        Me.lblErrorDrugType = New System.Windows.Forms.Label()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.hdrUnitQuantity = New System.Windows.Forms.Label()
        Me.txtUnitQuantity = New System.Windows.Forms.TextBox()
        Me.lblErrorUnitQty = New System.Windows.Forms.Label()
        Me.lblDateInfo = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'hdrDrugNDC
        '
        Me.hdrDrugNDC.AutoSize = True
        Me.hdrDrugNDC.Location = New System.Drawing.Point(40, 32)
        Me.hdrDrugNDC.Name = "hdrDrugNDC"
        Me.hdrDrugNDC.Size = New System.Drawing.Size(37, 17)
        Me.hdrDrugNDC.TabIndex = 14
        Me.hdrDrugNDC.Text = "NDC"
        '
        'hdrDrugName
        '
        Me.hdrDrugName.AutoSize = True
        Me.hdrDrugName.Location = New System.Drawing.Point(40, 82)
        Me.hdrDrugName.Name = "hdrDrugName"
        Me.hdrDrugName.Size = New System.Drawing.Size(80, 17)
        Me.hdrDrugName.TabIndex = 15
        Me.hdrDrugName.Text = "Drug Name"
        '
        'hdrDosage
        '
        Me.hdrDosage.AutoSize = True
        Me.hdrDosage.Location = New System.Drawing.Point(40, 134)
        Me.hdrDosage.Name = "hdrDosage"
        Me.hdrDosage.Size = New System.Drawing.Size(57, 17)
        Me.hdrDosage.TabIndex = 16
        Me.hdrDosage.Text = "Dosage"
        '
        'hdrDesc
        '
        Me.hdrDesc.AutoSize = True
        Me.hdrDesc.Location = New System.Drawing.Point(40, 188)
        Me.hdrDesc.Name = "hdrDesc"
        Me.hdrDesc.Size = New System.Drawing.Size(79, 17)
        Me.hdrDesc.TabIndex = 17
        Me.hdrDesc.Text = "Description"
        '
        'hdrUnitPrice
        '
        Me.hdrUnitPrice.AutoSize = True
        Me.hdrUnitPrice.Location = New System.Drawing.Point(40, 289)
        Me.hdrUnitPrice.Name = "hdrUnitPrice"
        Me.hdrUnitPrice.Size = New System.Drawing.Size(69, 17)
        Me.hdrUnitPrice.TabIndex = 18
        Me.hdrUnitPrice.Text = "Unit Price"
        '
        'hdrPackagePrice
        '
        Me.hdrPackagePrice.AutoSize = True
        Me.hdrPackagePrice.Location = New System.Drawing.Point(42, 334)
        Me.hdrPackagePrice.Name = "hdrPackagePrice"
        Me.hdrPackagePrice.Size = New System.Drawing.Size(99, 17)
        Me.hdrPackagePrice.TabIndex = 19
        Me.hdrPackagePrice.Text = "Package Price"
        '
        'hdrDateRecieved
        '
        Me.hdrDateRecieved.AutoSize = True
        Me.hdrDateRecieved.Location = New System.Drawing.Point(40, 378)
        Me.hdrDateRecieved.Name = "hdrDateRecieved"
        Me.hdrDateRecieved.Size = New System.Drawing.Size(101, 17)
        Me.hdrDateRecieved.TabIndex = 20
        Me.hdrDateRecieved.Text = "Date Recieved"
        '
        'hdrDrugType
        '
        Me.hdrDrugType.AutoSize = True
        Me.hdrDrugType.Location = New System.Drawing.Point(653, 240)
        Me.hdrDrugType.Name = "hdrDrugType"
        Me.hdrDrugType.Size = New System.Drawing.Size(75, 17)
        Me.hdrDrugType.TabIndex = 21
        Me.hdrDrugType.Text = "Drug Type"
        '
        'hdrSupplier
        '
        Me.hdrSupplier.AutoSize = True
        Me.hdrSupplier.Location = New System.Drawing.Point(653, 32)
        Me.hdrSupplier.Name = "hdrSupplier"
        Me.hdrSupplier.Size = New System.Drawing.Size(60, 17)
        Me.hdrSupplier.TabIndex = 22
        Me.hdrSupplier.Text = "Supplier"
        '
        'hdrCategory
        '
        Me.hdrCategory.AutoSize = True
        Me.hdrCategory.Location = New System.Drawing.Point(653, 76)
        Me.hdrCategory.Name = "hdrCategory"
        Me.hdrCategory.Size = New System.Drawing.Size(65, 17)
        Me.hdrCategory.TabIndex = 23
        Me.hdrCategory.Text = "Category"
        '
        'ddlSupplier
        '
        Me.ddlSupplier.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ddlSupplier.FormattingEnabled = True
        Me.ddlSupplier.Location = New System.Drawing.Point(765, 29)
        Me.ddlSupplier.Name = "ddlSupplier"
        Me.ddlSupplier.Size = New System.Drawing.Size(181, 24)
        Me.ddlSupplier.TabIndex = 54
        '
        'lstCategory
        '
        Me.lstCategory.FormattingEnabled = True
        Me.lstCategory.ItemHeight = 16
        Me.lstCategory.Location = New System.Drawing.Point(765, 79)
        Me.lstCategory.Name = "lstCategory"
        Me.lstCategory.ScrollAlwaysVisible = True
        Me.lstCategory.Size = New System.Drawing.Size(150, 100)
        Me.lstCategory.TabIndex = 55
        '
        'radOTC
        '
        Me.radOTC.AutoSize = True
        Me.radOTC.Location = New System.Drawing.Point(765, 240)
        Me.radOTC.Name = "radOTC"
        Me.radOTC.Size = New System.Drawing.Size(181, 21)
        Me.radOTC.TabIndex = 56
        Me.radOTC.TabStop = True
        Me.radOTC.Text = "OTC (Over the Counter)"
        Me.radOTC.UseVisualStyleBackColor = True
        '
        'radControlled
        '
        Me.radControlled.AutoSize = True
        Me.radControlled.Location = New System.Drawing.Point(765, 278)
        Me.radControlled.Name = "radControlled"
        Me.radControlled.Size = New System.Drawing.Size(93, 21)
        Me.radControlled.TabIndex = 57
        Me.radControlled.TabStop = True
        Me.radControlled.Text = "Controlled"
        Me.radControlled.UseVisualStyleBackColor = True
        '
        'radAntibiotic
        '
        Me.radAntibiotic.AutoSize = True
        Me.radAntibiotic.Location = New System.Drawing.Point(765, 315)
        Me.radAntibiotic.Name = "radAntibiotic"
        Me.radAntibiotic.Size = New System.Drawing.Size(93, 21)
        Me.radAntibiotic.TabIndex = 58
        Me.radAntibiotic.TabStop = True
        Me.radAntibiotic.Text = "Antibiotics"
        Me.radAntibiotic.UseVisualStyleBackColor = True
        '
        'radAntidepressants
        '
        Me.radAntidepressants.AutoSize = True
        Me.radAntidepressants.Location = New System.Drawing.Point(765, 357)
        Me.radAntidepressants.Name = "radAntidepressants"
        Me.radAntidepressants.Size = New System.Drawing.Size(131, 21)
        Me.radAntidepressants.TabIndex = 59
        Me.radAntidepressants.TabStop = True
        Me.radAntidepressants.Text = "Antidepressants"
        Me.radAntidepressants.UseVisualStyleBackColor = True
        '
        'hdrInStock
        '
        Me.hdrInStock.AutoSize = True
        Me.hdrInStock.Location = New System.Drawing.Point(419, 284)
        Me.hdrInStock.Name = "hdrInStock"
        Me.hdrInStock.Size = New System.Drawing.Size(58, 17)
        Me.hdrInStock.TabIndex = 30
        Me.hdrInStock.Text = "In Stock"
        '
        'hdrCount
        '
        Me.hdrCount.AutoSize = True
        Me.hdrCount.Location = New System.Drawing.Point(419, 240)
        Me.hdrCount.Name = "hdrCount"
        Me.hdrCount.Size = New System.Drawing.Size(45, 17)
        Me.hdrCount.TabIndex = 31
        Me.hdrCount.Text = "Count"
        '
        'txtDrugName
        '
        Me.txtDrugName.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.4!)
        Me.txtDrugName.Location = New System.Drawing.Point(164, 82)
        Me.txtDrugName.MaxLength = 40
        Me.txtDrugName.Name = "txtDrugName"
        Me.txtDrugName.Size = New System.Drawing.Size(302, 23)
        Me.txtDrugName.TabIndex = 45
        '
        'txtDesc
        '
        Me.txtDesc.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.4!)
        Me.txtDesc.Location = New System.Drawing.Point(164, 184)
        Me.txtDesc.MaxLength = 100
        Me.txtDesc.Name = "txtDesc"
        Me.txtDesc.Size = New System.Drawing.Size(564, 23)
        Me.txtDesc.TabIndex = 47
        '
        'txtUnitPrice
        '
        Me.txtUnitPrice.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.4!)
        Me.txtUnitPrice.Location = New System.Drawing.Point(163, 284)
        Me.txtUnitPrice.MaxLength = 6
        Me.txtUnitPrice.Name = "txtUnitPrice"
        Me.txtUnitPrice.Size = New System.Drawing.Size(151, 23)
        Me.txtUnitPrice.TabIndex = 49
        '
        'txtPackagePrice
        '
        Me.txtPackagePrice.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.4!)
        Me.txtPackagePrice.Location = New System.Drawing.Point(164, 330)
        Me.txtPackagePrice.MaxLength = 7
        Me.txtPackagePrice.Name = "txtPackagePrice"
        Me.txtPackagePrice.Size = New System.Drawing.Size(151, 23)
        Me.txtPackagePrice.TabIndex = 50
        '
        'txtCount
        '
        Me.txtCount.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.4!)
        Me.txtCount.Location = New System.Drawing.Point(503, 236)
        Me.txtCount.MaxLength = 4
        Me.txtCount.Name = "txtCount"
        Me.txtCount.Size = New System.Drawing.Size(66, 23)
        Me.txtCount.TabIndex = 51
        '
        'dtpDateRecieved
        '
        Me.dtpDateRecieved.CustomFormat = """MM/dd/yyyy"""
        Me.dtpDateRecieved.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpDateRecieved.Location = New System.Drawing.Point(164, 378)
        Me.dtpDateRecieved.MaxDate = New Date(2021, 10, 29, 0, 0, 0, 0)
        Me.dtpDateRecieved.MinDate = New Date(2019, 12, 25, 0, 0, 0, 0)
        Me.dtpDateRecieved.Name = "dtpDateRecieved"
        Me.dtpDateRecieved.Size = New System.Drawing.Size(302, 22)
        Me.dtpDateRecieved.TabIndex = 53
        Me.dtpDateRecieved.Value = New Date(2021, 9, 28, 0, 0, 0, 0)
        '
        'btnSave
        '
        Me.btnSave.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.btnSave.Location = New System.Drawing.Point(332, 433)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(90, 32)
        Me.btnSave.TabIndex = 60
        Me.btnSave.Text = "&Save"
        Me.btnSave.UseVisualStyleBackColor = True
        '
        'btnCancel
        '
        Me.btnCancel.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.btnCancel.Location = New System.Drawing.Point(860, 433)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(87, 32)
        Me.btnCancel.TabIndex = 62
        Me.btnCancel.Text = "&Cancel"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'chkInStock
        '
        Me.chkInStock.AutoSize = True
        Me.chkInStock.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.chkInStock.Location = New System.Drawing.Point(505, 287)
        Me.chkInStock.Name = "chkInStock"
        Me.chkInStock.Size = New System.Drawing.Size(18, 17)
        Me.chkInStock.TabIndex = 52
        Me.chkInStock.UseVisualStyleBackColor = True
        '
        'txtDosage
        '
        Me.txtDosage.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.4!)
        Me.txtDosage.Location = New System.Drawing.Point(164, 130)
        Me.txtDosage.MaxLength = 20
        Me.txtDosage.Name = "txtDosage"
        Me.txtDosage.Size = New System.Drawing.Size(151, 23)
        Me.txtDosage.TabIndex = 46
        '
        'mtbNDC
        '
        Me.mtbNDC.Location = New System.Drawing.Point(164, 32)
        Me.mtbNDC.Mask = "00000-0000-00"
        Me.mtbNDC.Name = "mtbNDC"
        Me.mtbNDC.Size = New System.Drawing.Size(151, 22)
        Me.mtbNDC.TabIndex = 44
        '
        'lblErrorNDC
        '
        Me.lblErrorNDC.AutoSize = True
        Me.lblErrorNDC.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblErrorNDC.ForeColor = System.Drawing.Color.Red
        Me.lblErrorNDC.Location = New System.Drawing.Point(314, 36)
        Me.lblErrorNDC.Name = "lblErrorNDC"
        Me.lblErrorNDC.Size = New System.Drawing.Size(16, 20)
        Me.lblErrorNDC.TabIndex = 45
        Me.lblErrorNDC.Text = "*"
        '
        'lblErrorDrugName
        '
        Me.lblErrorDrugName.AutoSize = True
        Me.lblErrorDrugName.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblErrorDrugName.ForeColor = System.Drawing.Color.Red
        Me.lblErrorDrugName.Location = New System.Drawing.Point(465, 85)
        Me.lblErrorDrugName.Name = "lblErrorDrugName"
        Me.lblErrorDrugName.Size = New System.Drawing.Size(16, 20)
        Me.lblErrorDrugName.TabIndex = 46
        Me.lblErrorDrugName.Text = "*"
        '
        'lblErrorDosage
        '
        Me.lblErrorDosage.AutoSize = True
        Me.lblErrorDosage.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblErrorDosage.ForeColor = System.Drawing.Color.Red
        Me.lblErrorDosage.Location = New System.Drawing.Point(314, 133)
        Me.lblErrorDosage.Name = "lblErrorDosage"
        Me.lblErrorDosage.Size = New System.Drawing.Size(16, 20)
        Me.lblErrorDosage.TabIndex = 47
        Me.lblErrorDosage.Text = "*"
        '
        'lblErrorDesc
        '
        Me.lblErrorDesc.AutoSize = True
        Me.lblErrorDesc.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblErrorDesc.ForeColor = System.Drawing.Color.Red
        Me.lblErrorDesc.Location = New System.Drawing.Point(727, 187)
        Me.lblErrorDesc.Name = "lblErrorDesc"
        Me.lblErrorDesc.Size = New System.Drawing.Size(16, 20)
        Me.lblErrorDesc.TabIndex = 48
        Me.lblErrorDesc.Text = "*"
        '
        'lblErrorUnitP
        '
        Me.lblErrorUnitP.AutoSize = True
        Me.lblErrorUnitP.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblErrorUnitP.ForeColor = System.Drawing.Color.Red
        Me.lblErrorUnitP.Location = New System.Drawing.Point(314, 287)
        Me.lblErrorUnitP.Name = "lblErrorUnitP"
        Me.lblErrorUnitP.Size = New System.Drawing.Size(16, 20)
        Me.lblErrorUnitP.TabIndex = 49
        Me.lblErrorUnitP.Text = "*"
        '
        'lblErrorPkgP
        '
        Me.lblErrorPkgP.AutoSize = True
        Me.lblErrorPkgP.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblErrorPkgP.ForeColor = System.Drawing.Color.Red
        Me.lblErrorPkgP.Location = New System.Drawing.Point(315, 332)
        Me.lblErrorPkgP.Name = "lblErrorPkgP"
        Me.lblErrorPkgP.Size = New System.Drawing.Size(16, 20)
        Me.lblErrorPkgP.TabIndex = 50
        Me.lblErrorPkgP.Text = "*"
        '
        'lblErrorInStock
        '
        Me.lblErrorInStock.AutoSize = True
        Me.lblErrorInStock.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblErrorInStock.ForeColor = System.Drawing.Color.Red
        Me.lblErrorInStock.Location = New System.Drawing.Point(520, 288)
        Me.lblErrorInStock.Name = "lblErrorInStock"
        Me.lblErrorInStock.Size = New System.Drawing.Size(16, 20)
        Me.lblErrorInStock.TabIndex = 51
        Me.lblErrorInStock.Text = "*"
        '
        'lblErrorCount
        '
        Me.lblErrorCount.AutoSize = True
        Me.lblErrorCount.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblErrorCount.ForeColor = System.Drawing.Color.Red
        Me.lblErrorCount.Location = New System.Drawing.Point(568, 238)
        Me.lblErrorCount.Name = "lblErrorCount"
        Me.lblErrorCount.Size = New System.Drawing.Size(16, 20)
        Me.lblErrorCount.TabIndex = 52
        Me.lblErrorCount.Text = "*"
        '
        'lblErrorDate
        '
        Me.lblErrorDate.AutoSize = True
        Me.lblErrorDate.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblErrorDate.ForeColor = System.Drawing.Color.Red
        Me.lblErrorDate.Location = New System.Drawing.Point(464, 381)
        Me.lblErrorDate.Name = "lblErrorDate"
        Me.lblErrorDate.Size = New System.Drawing.Size(16, 20)
        Me.lblErrorDate.TabIndex = 53
        Me.lblErrorDate.Text = "*"
        '
        'lblErrorSupplier
        '
        Me.lblErrorSupplier.AutoSize = True
        Me.lblErrorSupplier.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblErrorSupplier.ForeColor = System.Drawing.Color.Red
        Me.lblErrorSupplier.Location = New System.Drawing.Point(946, 30)
        Me.lblErrorSupplier.Name = "lblErrorSupplier"
        Me.lblErrorSupplier.Size = New System.Drawing.Size(16, 20)
        Me.lblErrorSupplier.TabIndex = 54
        Me.lblErrorSupplier.Text = "*"
        '
        'lblErrorCategory
        '
        Me.lblErrorCategory.AutoSize = True
        Me.lblErrorCategory.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblErrorCategory.ForeColor = System.Drawing.Color.Red
        Me.lblErrorCategory.Location = New System.Drawing.Point(914, 79)
        Me.lblErrorCategory.Name = "lblErrorCategory"
        Me.lblErrorCategory.Size = New System.Drawing.Size(16, 20)
        Me.lblErrorCategory.TabIndex = 55
        Me.lblErrorCategory.Text = "*"
        '
        'lblErrorDrugType
        '
        Me.lblErrorDrugType.AutoSize = True
        Me.lblErrorDrugType.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblErrorDrugType.ForeColor = System.Drawing.Color.Red
        Me.lblErrorDrugType.Location = New System.Drawing.Point(723, 244)
        Me.lblErrorDrugType.Name = "lblErrorDrugType"
        Me.lblErrorDrugType.Size = New System.Drawing.Size(16, 20)
        Me.lblErrorDrugType.TabIndex = 56
        Me.lblErrorDrugType.Text = "*"
        '
        'btnClear
        '
        Me.btnClear.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.btnClear.Location = New System.Drawing.Point(515, 433)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(87, 32)
        Me.btnClear.TabIndex = 61
        Me.btnClear.Text = "C&lear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'hdrUnitQuantity
        '
        Me.hdrUnitQuantity.AutoSize = True
        Me.hdrUnitQuantity.Location = New System.Drawing.Point(40, 240)
        Me.hdrUnitQuantity.Name = "hdrUnitQuantity"
        Me.hdrUnitQuantity.Size = New System.Drawing.Size(90, 17)
        Me.hdrUnitQuantity.TabIndex = 62
        Me.hdrUnitQuantity.Text = "Quantity/Unit"
        '
        'txtUnitQuantity
        '
        Me.txtUnitQuantity.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.4!)
        Me.txtUnitQuantity.Location = New System.Drawing.Point(163, 240)
        Me.txtUnitQuantity.MaxLength = 20
        Me.txtUnitQuantity.Name = "txtUnitQuantity"
        Me.txtUnitQuantity.Size = New System.Drawing.Size(151, 23)
        Me.txtUnitQuantity.TabIndex = 48
        '
        'lblErrorUnitQty
        '
        Me.lblErrorUnitQty.AutoSize = True
        Me.lblErrorUnitQty.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblErrorUnitQty.ForeColor = System.Drawing.Color.Red
        Me.lblErrorUnitQty.Location = New System.Drawing.Point(314, 243)
        Me.lblErrorUnitQty.Name = "lblErrorUnitQty"
        Me.lblErrorUnitQty.Size = New System.Drawing.Size(16, 20)
        Me.lblErrorUnitQty.TabIndex = 64
        Me.lblErrorUnitQty.Text = "*"
        '
        'lblDateInfo
        '
        Me.lblDateInfo.AutoSize = True
        Me.lblDateInfo.ForeColor = System.Drawing.SystemColors.ActiveBorder
        Me.lblDateInfo.Location = New System.Drawing.Point(487, 382)
        Me.lblDateInfo.Name = "lblDateInfo"
        Me.lblDateInfo.Size = New System.Drawing.Size(189, 17)
        Me.lblDateInfo.TabIndex = 65
        Me.lblDateInfo.Text = "Default Date is Today's Date"
        '
        'frmChangeDrugs
        '
        Me.AcceptButton = Me.btnSave
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.AliceBlue
        Me.ClientSize = New System.Drawing.Size(1009, 489)
        Me.Controls.Add(Me.lblDateInfo)
        Me.Controls.Add(Me.txtUnitQuantity)
        Me.Controls.Add(Me.lblErrorUnitQty)
        Me.Controls.Add(Me.hdrUnitQuantity)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.mtbNDC)
        Me.Controls.Add(Me.chkInStock)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnSave)
        Me.Controls.Add(Me.dtpDateRecieved)
        Me.Controls.Add(Me.txtCount)
        Me.Controls.Add(Me.txtPackagePrice)
        Me.Controls.Add(Me.txtUnitPrice)
        Me.Controls.Add(Me.txtDesc)
        Me.Controls.Add(Me.txtDosage)
        Me.Controls.Add(Me.txtDrugName)
        Me.Controls.Add(Me.hdrInStock)
        Me.Controls.Add(Me.hdrCount)
        Me.Controls.Add(Me.radAntidepressants)
        Me.Controls.Add(Me.radAntibiotic)
        Me.Controls.Add(Me.radControlled)
        Me.Controls.Add(Me.radOTC)
        Me.Controls.Add(Me.lstCategory)
        Me.Controls.Add(Me.ddlSupplier)
        Me.Controls.Add(Me.hdrDrugType)
        Me.Controls.Add(Me.hdrSupplier)
        Me.Controls.Add(Me.hdrCategory)
        Me.Controls.Add(Me.hdrDrugNDC)
        Me.Controls.Add(Me.hdrDrugName)
        Me.Controls.Add(Me.hdrDosage)
        Me.Controls.Add(Me.hdrDesc)
        Me.Controls.Add(Me.hdrUnitPrice)
        Me.Controls.Add(Me.hdrPackagePrice)
        Me.Controls.Add(Me.hdrDateRecieved)
        Me.Controls.Add(Me.lblErrorNDC)
        Me.Controls.Add(Me.lblErrorDrugName)
        Me.Controls.Add(Me.lblErrorDosage)
        Me.Controls.Add(Me.lblErrorDesc)
        Me.Controls.Add(Me.lblErrorUnitP)
        Me.Controls.Add(Me.lblErrorPkgP)
        Me.Controls.Add(Me.lblErrorInStock)
        Me.Controls.Add(Me.lblErrorCount)
        Me.Controls.Add(Me.lblErrorDate)
        Me.Controls.Add(Me.lblErrorCategory)
        Me.Controls.Add(Me.lblErrorSupplier)
        Me.Controls.Add(Me.lblErrorDrugType)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.Name = "frmChangeDrugs"
        Me.Text = "Update Drug (Aiman Haroon #73)"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents hdrDrugNDC As Label
    Friend WithEvents hdrDrugName As Label
    Friend WithEvents hdrDosage As Label
    Friend WithEvents hdrDesc As Label
    Friend WithEvents hdrUnitPrice As Label
    Friend WithEvents hdrPackagePrice As Label
    Friend WithEvents hdrDateRecieved As Label
    Friend WithEvents hdrDrugType As Label
    Friend WithEvents hdrSupplier As Label
    Friend WithEvents hdrCategory As Label
    Friend WithEvents ddlSupplier As ComboBox
    Friend WithEvents lstCategory As ListBox
    Friend WithEvents radOTC As RadioButton
    Friend WithEvents radControlled As RadioButton
    Friend WithEvents radAntibiotic As RadioButton
    Friend WithEvents radAntidepressants As RadioButton
    Friend WithEvents hdrInStock As Label
    Friend WithEvents hdrCount As Label
    Friend WithEvents txtDrugName As TextBox
    Friend WithEvents txtDesc As TextBox
    Friend WithEvents txtUnitPrice As TextBox
    Friend WithEvents txtPackagePrice As TextBox
    Friend WithEvents txtCount As TextBox
    Friend WithEvents dtpDateRecieved As DateTimePicker
    Friend WithEvents btnSave As Button
    Friend WithEvents btnCancel As Button
    Friend WithEvents chkInStock As CheckBox
    Friend WithEvents txtDosage As TextBox
    Friend WithEvents mtbNDC As MaskedTextBox
    Friend WithEvents lblErrorNDC As Label
    Friend WithEvents lblErrorDrugName As Label
    Friend WithEvents lblErrorDosage As Label
    Friend WithEvents lblErrorDesc As Label
    Friend WithEvents lblErrorUnitP As Label
    Friend WithEvents lblErrorPkgP As Label
    Friend WithEvents lblErrorInStock As Label
    Friend WithEvents lblErrorCount As Label
    Friend WithEvents lblErrorDate As Label
    Friend WithEvents lblErrorSupplier As Label
    Friend WithEvents lblErrorCategory As Label
    Friend WithEvents lblErrorDrugType As Label
    Friend WithEvents btnClear As Button
    Friend WithEvents hdrUnitQuantity As Label
    Friend WithEvents txtUnitQuantity As TextBox
    Friend WithEvents lblErrorUnitQty As Label
    Friend WithEvents lblDateInfo As Label
End Class
